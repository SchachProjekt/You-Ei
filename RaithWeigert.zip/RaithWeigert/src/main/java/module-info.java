module com.example.raithweigert {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.raithweigert to javafx.fxml;
    exports com.example.raithweigert;
}